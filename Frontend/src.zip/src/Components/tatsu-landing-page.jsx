import React from 'react'
import img from '../assets/images/header-logo-1.svg' 
import './tastu.css'
import mbdfs from '../assets/images/landing-page-group-img.png'
import first from '../assets/images/trending-product-1.png'
import two from '../assets/images/trending-product-2.png'
import three from '../assets/images/trending-product-3.png'
import four from '../assets/images/trending-product-1.png'
import  sixth from '../assets/images/tshirt-back-img.png'
import a from '../assets/images/trending-product-1.png'
import b from '../assets/images/trending-product-2.png'
import c from '../assets/images/trending-product-3.png'
import dd from  '../assets/images/footer-logo.png'
import { Link } from 'react-router-dom'
const Tatsu = () => {
  
  return (
    <>
    <div  className='bg-black  text-white'> Spend $50 for free shipping</div>


<div  className='flex justify-center text-black '>

    <img src={img} alt="" />
</div>
<div  className='mt-16 setmkol'>
<div    className='flex flex-col nnmm    w-10/12 h-full'>
<div  className='flex text-xl items-center text-center  	'>
  <div  className=' ajsnasjaskoj		 bg-black text-white'>SUBSCRIBE TO THE PLANS TO GRAB AMAZING DISCOUNTS AND OFFERS</div>
  <div className='  	ajsnasjaskoj bg-black text-white' >SUBSCRIBE TO THE PLANS TO GRAB AMAZING DISCOUNTS AND OFFERS</div>
</div>

<div   className="h-40 	justify-center notYouTyp	flex-col items-center	  flex bg-black text-white  mt-1">
  <span  className='text-xl native'>VIP MEMBERSHIP OFFERS</span>
  <span  className='text-2xl native2'>BUY ONE, GET TWO FREE T-SHIRTS</span>
  <Link to={'/SignupForm1'}><a class="mashdbiuasj" href="#" role="button">SHOP NOW!</a></Link> 
  
</div>

</div>
</div>






{/* Third  */}
<div  className='mkhffx  '>
  

  <div  className='asfdsvmnkm' >
    <img  style={{"height": "100%"}} src={mbdfs}alt="" />
  </div>
<div  className='mllsjdsiahb'  >
  <h1   className='text-5xl  asdasnb my-5'>What We Offer</h1>
  <div className='mhbjhft' >
  <div><p  className='notyuio' >Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the </p></div>
<div><p  className='notyuio' >Lorem Ipsum is simply dummy text of the printing</p></div>  
</div>

<div  className='my-12'>
  <ul  className='mkhvh'>
    <li className='mb-2  notyuio'>Lorem ipsum, dolor sit amet </li>
    <li className='mb-2  notyuio'>Lorem ipsum, dolor sit amet consectetur adipisicing elit.</li>
    <li className='mb-2  notyuio'>Lorem ipsum, dolor sit amet consectetur adipisicing elit.</li>
    <li className='mb-2 notyuio'  >Lorem ipsum, dolor sit amet consectetur adipisicing elit.</li>
  </ul>
</div>
</div>

</div>





{/* Forth Part */}

<div  className='mndasjdbhasiu'>
<section id="landing-page-sec3 asdasdasdasdasdas ">
    <div class="container">
            <h3  className='text-4xl my-10 mkjuffd'>Trending Now</h3>
        <div class="row askndaskasdkas">
            <div class=" basdsad col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12 trending-col">
                <img  className='setImageshadow' src={first} class="img-fluid"/>
            </div>
            <div class="basdsad col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12 trending-col">
                <img  className='setImageshadow' src={two} class="img-fluid"/>
            </div>
            <div class="basdsad col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12 trending-col">
                <img  className='setImageshadow' src={three} class="img-fluid"/>
            </div>
            <div class="basdsad col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12 trending-col">
                <img  className='setImageshadow' src={four} class="img-fluid"/>
            </div>
        </div>
    </div>
</section>
</div>

{/* FiFth Part  */}

<div className='adawddwq' >
<section id="landing-page-sec4">
    <div class=" ">
        <div class="row  flex">
            <div class="  col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 tales-threads">
                <img  style={{"height" :  "100%"}} src={sixth}  alt="Not Found" />
            </div>
            <div class=" flex flex-col asasnasbashjxsh col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 tales-threads-matter">
                <h5  className='smahdiasd'>Tales Of Tatsu Threads</h5>


                <div  className='setwidthmnbyh'>

                <p className='notyuio'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
                    when an unknown printer took a galley of type and scrambled it to make a type 
                    specimen book. It has survived not only five centuries, but also the leap into 
                    electronic typesetting, remaining essentially unchanged. It was popularised in 
                    the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, 
                    and more recently with desktop publishing software like Aldus PageMaker including 
                    versions of Lorem Ipsum.It has survived not only five centuries, but also the leap into 
                    electronic typesetting, remaining essentially unchanged. It was popularised in 
                    the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, 
                    and more recently with desktop publishing software like Aldus PageMaker including 
                    versions of Lorem Ipsum.</p>
                </div>
            </div>
        </div>
    </div>
</section>
</div>



{/* Sixth Part */}

<div  className='hbbrd'>
<section id="landing-page-sec5">
    <div class="">
            <h3  className='mkjuff'>Why Every Obsessed</h3>
        <div class="row  nmflsd">
            <div class="nmnsd   every-obsessed">
                <img className='mkiujn'   clas src={a} class="img-fluid"/>
                <h4   className='setfontg' >Kenshi (My Beloved T-Shirt)</h4>
                <p  className='setParaID'  >Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
                    when an unknown printer took a galley of type and scrambled it to make a type 
                    specimen book.</p>
            </div>
            <div class=" nmnsd    every-obsessed">
                <img className='mkiujn'  src={b} class="img-fluid"/>
                <h4   className='setfontg'>Kenshi (My Beloved T-Shirt)</h4>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
                    when an unknown printer took a galley of type and scrambled it to make a type 
                    specimen book.</p>
            </div>
            <div class=" nmnsd col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12 every-obsessed">
                <img className='mkiujn'  src={c} class="img-fluid"/>
                <h4   className='setfontg'>Kenshi (My Beloved T-Shirt)</h4>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
                    when an unknown printer took a galley of type and scrambled it to make a type 
                    specimen book.</p>
            </div>
        </div>
    </div>
</section>
</div>







{/* Footer */}


<div class="pg-footer">
      <footer class="footer">
        {/* <svg class="footer-wave-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 100" preserveAspectRatio="none">
          <path class="footer-wave-path" d="M851.8,100c125,0,288.3-45,348.2-64V0H0v44c3.7-1,7.3-1.9,11-2.9C80.7,22,151.7,10.8,223.5,6.3C276.7,2.9,330,4,383,9.8 c52.2,5.7,103.3,16.2,153.4,32.8C623.9,71.3,726.8,100,851.8,100z"></path>
        </svg> */}
        <div class="footer-content">
          <div class="footer-content-column">
            <div class="footer-logo">
              <a class="footer-logo-link" href="#">
                <span class="hidden-link-text">LOGO</span>
                <img src={dd} alt="" />
              </a>
            </div>
            <div class="footer-menu">
              <h2 class="footer-menu-name"> Get Started</h2>
              <ul id="menu-get-started" class="footer-menu-list">
                <li class="menu-item menu-item-type-post_type menu-item-object-product">
                  <a href="#">Start</a>
                </li>
                <li class="menu-item menu-item-type-post_type menu-item-object-product">
                  <a href="#">Documentation</a>
                </li>
                <li class="menu-item menu-item-type-post_type menu-item-object-product">
                  <a href="#">Installation</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="footer-content-column">
            <div class="footer-menu">
              <h2 class="footer-menu-name"> Company</h2>
              <ul id="menu-company" class="footer-menu-list">
                <li class="menu-item menu-item-type-post_type menu-item-object-page">
                  <a href="#">Contact</a>
                </li>
                <li class="menu-item menu-item-type-taxonomy menu-item-object-category">
                  <a href="#">News</a>
                </li>
                <li class="menu-item menu-item-type-post_type menu-item-object-page">
                  <a href="#">Careers</a>
                </li>
              </ul>
            </div>
            <div class="footer-menu">
              <h2 class="footer-menu-name"> Legal</h2>
              <ul id="menu-legal" class="footer-menu-list">
                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-170434">
                  <a href="#">Privacy Notice</a>
                </li>
                <li class="menu-item menu-item-type-post_type menu-item-object-page">
                  <a href="#">Terms of Use</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="footer-content-column">
            <div class="footer-menu">
              <h2 class="footer-menu-name"> Quick Links</h2>
              <ul id="menu-quick-links" class="footer-menu-list">
                <li class="menu-item menu-item-type-custom menu-item-object-custom">
                  <a target="_blank" rel="noopener noreferrer" href="#">Support Center</a>
                </li>
                <li class="menu-item menu-item-type-custom menu-item-object-custom">
                  <a target="_blank" rel="noopener noreferrer" href="#">Service Status</a>
                </li>
                <li class="menu-item menu-item-type-post_type menu-item-object-page">
                  <a href="#">Security</a>
                </li>
                <li class="menu-item menu-item-type-post_type menu-item-object-page">
                  <a href="#">Blog</a>
                </li>
                <li class="menu-item menu-item-type-post_type_archive menu-item-object-customer">
                  <a href="#">Customers</a></li>
                <li class="menu-item menu-item-type-post_type menu-item-object-page">
                  <a href="#">Reviews</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="footer-content-column">
            <div class="footer-call-to-action">
              <h2 class="footer-call-to-action-title"> Let's Chat</h2>
              <p class="footer-call-to-action-description"> Have a support question?</p>

              <div className='adsufv'>
              <input className='border-1  kkll border-whites rounded-sm px-4 py-1'  placeholder='Email Address' type="text" name="" id="" />
              <button className='nnju  border-black text-xl text-black mt-6 px-11 py-4 '>SUBSCRIBE</button>
              </div>
            </div>
            <div class="footer-call-to-action">
              <h2 class="footer-call-to-action-title"> You Call Us</h2>
              <p class="footer-call-to-action-link-wrapper"> <a class="footer-call-to-action-link" href="tel:0124-64XXXX" target="_self"> Ahmed</a></p>
            </div>
          </div>
        
        </div>
        
      </footer>
    </div>
    
   
    </>
  )
}

export default Tatsu